#!/bin/sh

zip -r lambda.zip .
mv lambda.zip ../../packages/ServiceCreation/
