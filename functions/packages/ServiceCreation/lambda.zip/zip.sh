#!/bin/sh -x

zip -r lambda.zip .
mv lambda.zip ../../packages/ServiceCreation/
